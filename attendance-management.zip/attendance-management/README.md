# Student Attendance Management System

A React + Vite college attendance management application for faculty.

## Features

- Reusable Header, StudentList, StudentCard, Attendance and Summary components
- Props passed between parent and child components
- `useState()` for attendance state management
- Mark student Present / Absent
- Dynamically increase/decrease attendance percentage
- Eligibility rule: attendance >= 75%
- Highlights students below 75%
- Dynamic attendance summary
- Search by student name, roll number or branch
- Reset attendance
- Responsive dashboard UI

## Run the project

Make sure Node.js is installed.

```bash
npm install
npm run dev
```

Open the URL shown by Vite, usually:

http://localhost:5173/

## Build for production

```bash
npm run build
```

## Component structure

```text
src/
├── components/
│   ├── Header.jsx
│   ├── StudentList.jsx
│   ├── StudentCard.jsx
│   ├── Attendance.jsx
│   └── Summary.jsx
├── App.jsx
├── main.jsx
└── styles.css
```

## Props flow

App
 ├── Header
 ├── Summary
 │     └── receives summary values as props
 └── StudentList
       └── StudentCard
             └── Attendance
                   └── receives attendance + event handlers as props
