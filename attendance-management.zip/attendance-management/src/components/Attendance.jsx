function Attendance({
  name,
  rollNumber,
  attendance,
  onPresent,
  onAbsent
}) {
  return (
    <div className="attendance-box">
      <div className="progress-row">
        <span>Attendance for {name} ({rollNumber})</span>
        <strong>{attendance}%</strong>
      </div>

      <div className="progress-track">
        <div
          className="progress-fill"
          style={{ width: `${attendance}%` }}
        />
      </div>

      <div className="attendance-actions">
        <button className="present-btn" onClick={onPresent}>
          ✓ Present (+1%)
        </button>
        <button className="absent-btn" onClick={onAbsent}>
          ✕ Absent (-1%)
        </button>
      </div>
    </div>
  );
}

export default Attendance;