import StudentCard from "./StudentCard";

function StudentList({ students, onPresent, onAbsent }) {
  if (students.length === 0) {
    return (
      <div className="empty">
        <div className="empty-icon">🔎</div>
        <h3>No students found</h3>
        <p>Try a different name, roll number, or branch.</p>
      </div>
    );
  }

  return (
    <section className="student-grid">
      {students.map((student) => (
        <StudentCard
          key={student.id}
          student={student}
          onPresent={onPresent}
          onAbsent={onAbsent}
        />
      ))}
    </section>
  );
}

export default StudentList;