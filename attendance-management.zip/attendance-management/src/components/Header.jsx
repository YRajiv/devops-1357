function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="logo">🎓</div>
        <div>
          <h1>Student Attendance Management System</h1>
          <p>College Faculty Portal</p>
        </div>
      </div>
    </header>
  );
}

export default Header;