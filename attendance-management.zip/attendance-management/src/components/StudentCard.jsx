import Attendance from "./Attendance";

function StudentCard({ student, onPresent, onAbsent }) {
  const isEligible = student.attendance >= 75;
  const isLowAttendance = student.attendance < 75;

  return (
    <article className={`student-card ${isLowAttendance ? "low-attendance" : ""}`}>
      <div className="student-top">
        <div className="avatar">{student.name.charAt(0)}</div>
        <div>
          <h3>{student.name}</h3>
          <p>{student.rollNumber}</p>
        </div>
        <span className={`status ${isEligible ? "eligible" : "not-eligible"}`}>
          {isEligible ? "Eligible" : "Not Eligible"}
        </span>
      </div>

      <div className="details">
        <div>
          <span>Branch</span>
          <strong>{student.branch}</strong>
        </div>
        <div>
          <span>Attendance</span>
          <strong className={isLowAttendance ? "danger-text" : ""}>
            {student.attendance}%
          </strong>
        </div>
      </div>

      <Attendance
        name={student.name}
        rollNumber={student.rollNumber}
        attendance={student.attendance}
        onPresent={() => onPresent(student.id)}
        onAbsent={() => onAbsent(student.id)}
      />

      {isLowAttendance && (
        <div className="warning">⚠ Attendance is below the required 75%.</div>
      )}
    </article>
  );
}

export default StudentCard;