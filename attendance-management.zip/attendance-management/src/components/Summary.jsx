function Summary({ present, absent, eligible, total }) {
  const eligibilityRate = total
    ? Math.round((eligible / total) * 100)
    : 0;

  return (
    <section className="summary-grid">
      <div className="summary-card">
        <span className="summary-icon">👥</span>
        <div>
          <p>Total Students</p>
          <h3>{total}</h3>
        </div>
      </div>

      <div className="summary-card">
        <span className="summary-icon">✓</span>
        <div>
          <p>Present / Eligible</p>
          <h3>{present}</h3>
        </div>
      </div>

      <div className="summary-card">
        <span className="summary-icon">⚠</span>
        <div>
          <p>Below 75%</p>
          <h3>{absent}</h3>
        </div>
      </div>

      <div className="summary-card">
        <span className="summary-icon">📊</span>
        <div>
          <p>Eligibility Rate</p>
          <h3>{eligibilityRate}%</h3>
        </div>
      </div>
    </section>
  );
}

export default Summary;