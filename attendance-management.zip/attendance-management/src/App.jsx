import { useState } from "react";
import Header from "./components/Header";
import StudentList from "./components/StudentList";
import Summary from "./components/Summary";

const initialStudents = [
  { id: 1, name: "Rahul", rollNumber: "CSE101", branch: "CSE", attendance: 82 },
  { id: 2, name: "Priya", rollNumber: "CSE102", branch: "CSE", attendance: 68 },
  { id: 3, name: "Arjun", rollNumber: "CSE103", branch: "CSE", attendance: 91 },
  { id: 4, name: "Sneha", rollNumber: "CSE104", branch: "CSE", attendance: 74 },
  { id: 5, name: "Vikram", rollNumber: "CSE105", branch: "CSE", attendance: 79 }
];

const createInitialStudents = () => initialStudents.map((student) => ({ ...student }));

function App() {
  const [students, setStudents] = useState(createInitialStudents);
  const [searchTerm, setSearchTerm] = useState("");

  const markPresent = (id) => {
    setStudents((currentStudents) =>
      currentStudents.map((student) =>
        student.id === id
          ? { ...student, attendance: Math.min(student.attendance + 1, 100) }
          : student
      )
    );
  };

  const markAbsent = (id) => {
    setStudents((currentStudents) =>
      currentStudents.map((student) =>
        student.id === id
          ? { ...student, attendance: Math.max(student.attendance - 1, 0) }
          : student
      )
    );
  };

  const resetAttendance = () => {
    setStudents(createInitialStudents());
  };

  const filteredStudents = students.filter((student) =>
    `${student.name} ${student.rollNumber} ${student.branch}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  const presentStudents = students.filter((student) => student.attendance >= 75).length;
  const absentStudents = students.filter((student) => student.attendance < 75).length;
  const eligibleStudents = students.filter((student) => student.attendance >= 75).length;

  return (
    <div className="app">
      <Header />

      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">FACULTY DASHBOARD</p>
            <h2>Manage Student Attendance</h2>
            <p className="subtitle">
              Update attendance, check examination eligibility, and search students.
            </p>
          </div>

          <button className="reset-btn" onClick={resetAttendance}>
            Reset Attendance
          </button>
        </section>

        <Summary
          present={presentStudents}
          absent={absentStudents}
          eligible={eligibleStudents}
          total={students.length}
        />

        <section className="toolbar">
          <input
            type="text"
            placeholder="Search by name, roll number or branch..."
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
          />
          <span>{filteredStudents.length} student(s) found</span>
        </section>

        <StudentList
          students={filteredStudents}
          onPresent={markPresent}
          onAbsent={markAbsent}
        />
      </main>
    </div>
  );
}

export default App;